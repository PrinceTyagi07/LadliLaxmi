// File: src/pages/Dashboard.jsx
import { useAuth } from '../context/AuthContext';
import { useEffect, useState } from 'react';
import axiosInstance from '../api/axiosInstance';
import { Link, useLocation } from 'react-router-dom';

export default function Dashboard() {
  const { admin, logout } = useAuth();
  const [summary, setSummary] = useState(null);
  const location = useLocation();

  useEffect(() => {
    const fetchSummary = async () => {
      try {
        const res = await axiosInstance.get('/admin/summary');
        setSummary(res.data);
      } catch (err) {
        alert('Session expired or unauthorized. Logging out.');
        logout();
      }
    };

    fetchSummary();
  }, [logout]);

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-800 text-white p-4">
        <h2 className="text-2xl font-bold mb-6">Admin Panel</h2>
        <nav className="space-y-2">
          <Link to="/dashboard" className={`block px-2 py-1 rounded hover:bg-gray-700 ${location.pathname === '/dashboard' ? 'bg-gray-700' : ''}`}>Dashboard</Link>
          <Link to="/dashboard/users" className={`block px-2 py-1 rounded hover:bg-gray-700 ${location.pathname === '/dashboard/users' ? 'bg-gray-700' : ''}`}>Manage Users</Link>
          <Link to="/dashboard/donations" className={`block px-2 py-1 rounded hover:bg-gray-700 ${location.pathname === '/dashboard/donations' ? 'bg-gray-700' : ''}`}>Donations</Link>
        </nav>
        <button onClick={logout} className="mt-6 bg-red-600 hover:bg-red-700 w-full py-2 rounded">
          Logout
        </button>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 bg-gray-100">
        <h1 className="text-3xl font-bold mb-4">Welcome, {admin?.name}</h1>

        {summary ? (
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-green-100 p-4 rounded">Total Users: {summary.usersCount}</div>
            <div className="bg-blue-100 p-4 rounded">Donations: {summary.totalDonations}</div>
            <div className="bg-yellow-100 p-4 rounded">Approved: {summary.approved}</div>
            <div className="bg-red-100 p-4 rounded">Pending: {summary.pending}</div>
          </div>
        ) : (
          <p>Loading summary...</p>
        )}
      </main>
    </div>
  );
} 
