// File: src/pages/Donations.jsx
import { useEffect, useState } from 'react';
import axiosInstance from '../api/axiosInstance';

export default function Donations() {
  const [donations, setDonations] = useState([]);

  const fetchDonations = async () => {
    try {
      const res = await axiosInstance.get('/admin/donations');
      setDonations(res.data);
    } catch (err) {
      alert('Failed to load donations');
    }
  };

  const handleApprove = async (id) => {
    try {
      await axiosInstance.post(`/admin/donations/${id}/approve`);
      fetchDonations();
    } catch (err) {
      alert('Approval failed');
    }
  };

  useEffect(() => {
    fetchDonations();
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Manage Donations</h1>
      <table className="min-w-full bg-white shadow rounded">
        <thead className="bg-gray-200">
          <tr>
            <th className="py-2 px-4 text-left">User</th>
            <th className="py-2 px-4 text-left">Amount</th>
            <th className="py-2 px-4 text-left">Date</th>
            <th className="py-2 px-4 text-left">Status</th>
            <th className="py-2 px-4">Actions</th>
          </tr>
        </thead>
        <tbody>
          {donations.map((don) => (
            <tr key={don._id} className="border-b">
              <td className="py-2 px-4">{don.user?.name}</td>
              <td className="py-2 px-4">₹{don.amount}</td>
              <td className="py-2 px-4">{new Date(don.createdAt).toLocaleDateString()}</td>
              <td className="py-2 px-4">{don.status}</td>
              <td className="py-2 px-4 text-center">
                {don.status === 'pending' && (
                  <button
                    className="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded"
                    onClick={() => handleApprove(don._id)}
                  >
                    Approve
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
