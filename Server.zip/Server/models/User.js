const mongoose = require("mongoose");
const bcrypt = require("bcryptjs"); // For password hashing

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
    },
    referralCode: {
      type: String,
      unique: true,
      required: true,
      default: function () {
        // Generate a unique referral code (e.g., using a random string or user ID)
        return this._id.toString().substring(0, 8); // Example: first 8 characters of ObjectId
      },
    },
    referredBy: {
      type: String,
      require: true, // This can be used to track who referred the user
    },
    // referrerId: { // ID of the user who referred this user (their direct upline)
    //     type: mongoose.Schema.Types.ObjectId,
    //     ref: 'User',
    //     default: null
    // },
    matrixChildren: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    currentLevel: {
      type: Number,
      default: 0, // 0 for unregistered/unactivated, 1 for active Level 1
    },
    // totalDonationsReceived: {
    //     type: Number,
    //     default: 0
    // },
    // totalDonationsMade: {
    //     type: Number,
    //     default: 0
    // },
    donationsSent: [{ type: mongoose.Schema.Types.ObjectId, ref: "Donation" }],
    donationsReceived: [
      { type: mongoose.Schema.Types.ObjectId, ref: "Donation" },
    ],
    walletBalance: {
      // Balance available for withdrawal/upgrades
      type: Number,
      default: 0,
    },
    // Array of users directly referred by this user (Level 1)
    directReferrals: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    token: {
      type: String,
    },
    role: {
      type: String,
      enum: ["user", "admin"],
      default: "user",
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

// // Hash password before saving
// userSchema.pre('save', async function(next) {
//     if (!this.isModified('password')) {
//         return next();
//     }
//     const salt = await bcrypt.genSalt(10);
//     this.password = await bcrypt.hash(this.password, salt);
//     next();
// });

// // Method to compare passwords
// userSchema.methods.matchPassword = async function(enteredPassword) {
//     return await bcrypt.compare(enteredPassword, this.password);
// };

module.exports = mongoose.model("User", userSchema);
