const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
    senderId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    receiverId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    amount: {
        type: Number,
        required: true
    },
    level: { // The level at which this transaction occurred (e.g., Level 1 activation, Level 2 upgrade)
        type: Number,
        required: true
    },
    type: { // 'donation_in', 'donation_out', 'upgrade_cost', 'withdrawal', 'level_donation'
        type: String,
        required: true,
        enum: ['donation_in', 'donation_out', 'upgrade_cost', 'withdrawal', 'level_donation']
    },
    status: { // 'pending', 'completed', 'failed', 'rejected'
        type: String,
        required: true,
        enum: ['pending', 'completed', 'failed', 'rejected']
    },
    paymentProof: { // For manual verification (e.g., image URL)
        type: String
    },
    notes: {
        type: String
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Transaction', transactionSchema);