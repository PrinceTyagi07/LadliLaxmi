const express = require("express");
const Donation = require("../models/Donation");
const User = require("../models/User");

const router = express.Router();

// Provide Help API
router.post("/provide", async (req, res) => {
  const { userId, level, amount } = req.body;
  try {
    const donor = await User.findById(userId);
    if (!donor) return res.status(404).json({ message: "Donor not found" });
    // Determine receiver (donor's upline)
    const receiver = await User.findOne({ referralCode: donor.referredBy });
    if (!receiver) return res.status(404).json({ message: "Upline not found" });

    // Create donation entry
    const donation = new Donation({
      donor: donor._id,
      receiver: receiver._id,
      level,
      amount,
      status: "pending",
    });

    await donation.save();

    // Add donation references to both users
    donor.donationsSent.push(donation._id);
    receiver.donationsReceived.push(donation._id);
    await donor.save();
    await receiver.save();

    res.json({ message: "Donation initiated", donation });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

router.post('/approve', async (req, res) => {
const { donationId } = req.body;

const donation = await Donation.findById(donationId);
if (!donation) return res.status(404).json({ message: 'Donation not found' });

donation.status = 'approved';
await donation.save();

res.json({ message: 'Donation approved', donation });
});


module.exports = router;
