const express = require('express');
const User = require('../models/User');
const Donation = require('../models/Donation');
const isAdmin = require('../middleware/adminAuth');

const router = express.Router();

// 1. All users list
router.get('/users', isAdmin, async (req, res) => {
const users = await User.find().select('-password').populate('donationsSent donationsReceived');
res.json(users);
});

// 2. All donations list
router.get('/donations', isAdmin, async (req, res) => {
const donations = await Donation.find().populate('donor receiver');
res.json(donations);
});

// 3. Approve a donation
router.post('/donation/approve', isAdmin, async (req, res) => {
const { donationId } = req.body;
const donation = await Donation.findById(donationId);
if (!donation) return res.status(404).json({ message: 'Donation not found' });

donation.status = 'approved';
await donation.save();
res.json({ message: 'Donation approved' });
});

// 4. Reject a donation
router.post('/donation/reject', isAdmin, async (req, res) => {
const { donationId } = req.body;
const donation = await Donation.findById(donationId);
if (!donation) return res.status(404).json({ message: 'Donation not found' });

donation.status = 'rejected';
await donation.save();
res.json({ message: 'Donation rejected' });
});

// 5. Stats summary
router.get('/summary', isAdmin, async (req, res) => {
const usersCount = await User.countDocuments();
const totalDonations = await Donation.countDocuments();
const approved = await Donation.countDocuments({ status: 'approved' });
const pending = await Donation.countDocuments({ status: 'pending' });

res.json({
usersCount,
totalDonations,
approved,
pending,
});
});


router.delete('/users/:id', verifyToken, isAdmin, async (req, res) => {
try {
await User.findByIdAndDelete(req.params.id);
res.json({ message: 'User deleted' });
} catch (err) {
res.status(500).json({ error: 'Error deleting user' });
}
});
module.exports = router;

// GET /api/admin/users → list all users

// GET /api/admin/donations → all donations (with donor & receiver)

// POST /api/admin/donation/approve → approve by donationId

// POST /api/admin/donation/reject → reject

// GET /api/admin/summary → platform stats